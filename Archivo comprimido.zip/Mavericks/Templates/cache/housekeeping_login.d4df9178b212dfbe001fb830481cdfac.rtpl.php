<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Panel de administraccion HabboCrazy, cuidado puedes ser baneado">
    <meta name="author" content="|Lion">

    <title>HabboCrazy » Panel de control</title>
    <link href="<?php echo $CDN;?>/css/vendor/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $CDN;?>/css/ase/login.css" rel="stylesheet">

    <script type="text/javascript">
      var Hotelname   = '<?php echo $SITENAME;?>';
      var SITEPATH    = '<?php echo $PATH;?>';
      var ACTIONS_URL = '<?php echo $ACTIONS_URL;?>';
    </script>
  </head>

  <body>

    <div class="container">
        <div class="form-signin">
          <h2 class="form-signin-heading">Por favor, inicia seccion</h2>

          <div id="results" style="display:none"></div>

          <input type="text" id="username" class="input-block-level" placeholder="Nombre de usuario" autofocus style="width:100%">
          <input type="password" id="password" class="input-block-level" placeholder="Contraseña" style="width:100%">
          <button class="btn btn-large btn-primary btn-block" type="submit" onclick="Ase.Login()">Acceder ahora</button>
        </div>
    </div> 

    <footer style="text-align:center; margin-top: 15px">
        Copyright Mavericks trynity &copy; &nbsp; 2013 » all rights reserved
    </footer>

  <script type="text/javascript" src="<?php echo $CDN;?>/js/vendor/jquery-2.0.3.min.js"></script>
  <script type="text/javascript" src="<?php echo $CDN;?>/js/ase.js"></script>
  </body>
</html>